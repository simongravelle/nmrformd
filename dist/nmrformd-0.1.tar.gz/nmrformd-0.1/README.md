# NMR relaxation time calculator

Python script for the calculation of NMR relaxation time T1 and T2 from molecular dynamics trajectory file. 
